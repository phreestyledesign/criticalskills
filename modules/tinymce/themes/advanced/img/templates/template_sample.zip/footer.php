<?php
/**
* @project ApPHP MicroCMS
* @copyright (c) 2012 ApPHP
* @author ApPHP <info@apphp.com>
* @license http://www.gnu.org/licenses/
*/

// *** Make sure the file isn"t accessed directly
defined("APPHP_EXEC") or die("Restricted Access");
//--------------------------------------------------------------------------

?>

<div class="footer">
    <?php 
        // Draw footer menu
        Menu::DrawFooterMenu();	
    ?>		  

    <form name="frmLogout" id="frmLogout" style="padding:0px;margin:0px;" action="index.php" method="post">
        <?php echo $objSiteDescription->DrawFooter(); ?>
        <?php echo "&nbsp;".draw_divider(false)."&nbsp;"; ?>
        <?php if($objLogin->IsLoggedIn()){ ?>
            <?php draw_hidden_field("submit_logout", "logout"); ?>
            <a class="main_link" href="javascript:frmLogout_Submit();"><?php echo _BUTTON_LOGOUT; ?></a>
        <?php
            }else{
                echo prepare_permanent_link('index.php?admin=login', _ADMIN_LOGIN, '', 'main_link');
            }
        ?>
    </form>
</div>
