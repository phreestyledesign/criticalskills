<?php

// *** Make sure the file isn"t accessed directly
defined("APPHP_EXEC") or die("Restricted Access");
//--------------------------------------------------------------------------
?>

<a href="<?php echo APPHP_BASE; ?>index.php"><?php echo ($objLogin->IsLoggedInAsAdmin() && $preview != "yes") ? _ADMIN_PANEL : $objSiteDescription->DrawHeader("header_text"); ?></a>
<br>
<?php
	if($objLogin->IsLoggedInAsAdmin() && $preview == "yes"){
		echo prepare_permanent_link('index.php?preview=no', _BACK_TO_ADMIN_PANEL, "", "header");
	}else{
		echo $objSiteDescription->GetParameter("slogan_text");				
	}
?>

<div id="navWrapper">	
	<!-- language -->
	<div class="nav_language <?php echo "float_".Application::Get("defined_left"); ?>">
		<?php				
			$objLang = new Languages();				
			if($objLang->GetLanguagesCount("front-end") > 1){							
				echo "<div style='padding-top:4px;float:left;'>";
				echo _LANGUAGES." ";			
				$objLang->DrawLanguagesBar();
				echo "</div>";
			}				
		?>		
	</div>
	
	<!-- search -->
	<?php			
		$keyword = isset($_POST['keyword']) ? trim(prepare_input($_POST['keyword'])) : _SEARCH_KEYWORDS."...";
		$keyword   = str_replace('"', "&#034;", $keyword);
		$keyword   = str_replace("'", "&#039;", $keyword);			
	?>
	<div class="header_search <?php echo "float_".Application::Get("defined_right"); ?>">
		<form name="frmQuickSearch" action="index.php?page=search" method="post">
			<input type="hidden" name="task" value="quick_search">
			<input type="hidden" name="p" value="1">						
			<input onblur="if(this.value == '') this.value='<?php echo _SEARCH_KEYWORDS;?>...';" onfocus="if(this.value == '<?php echo _SEARCH_KEYWORDS;?>...') this.value = '';" maxLength="30" size="<?php echo strlen(_SEARCH_KEYWORDS);?>" value="<?php echo $keyword;?>" name="keyword">						
			<input type='submit' value="<?php echo _SEARCH; ?>" onclick='appQuickSearch()'>
		</form>
	</div>
</div>